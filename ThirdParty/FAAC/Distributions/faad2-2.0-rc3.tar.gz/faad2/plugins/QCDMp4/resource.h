//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by QCDMp4.rc
//
#define IDD_INFO                        101
#define IDD_CONFIG                      102
#define IDD_CONFIG_INPUT                102
#define IDD_ABOUT                       103
#define IDD_CONFIG_CONVERT              104
#define IDB_LOGO                        105
#define IDC_TYPE                        1000
#define IDC_INFOTEXT                    1000
#define IDC_DURATION                    1001
#define IDC_BITRATE                     1002
#define IDC_SAMPLERATE                  1003
#define IDC_VTYPE                       1004
#define IDC_PRIORITY                    1004
#define IDC_VBITRATE                    1005
#define IDC_ERROR                       1005
#define IDC_VDURATION                   1006
#define IDC_16BITS                      1006
#define IDC_VSIZE                       1007
#define IDC_24BITS                      1007
#define IDC_CONVERT                     1007
#define IDC_VFPS                        1008
#define IDC_32BITS                      1008
#define IDC_CONVERT2                    1008
#define IDC_CHANNELS                    1009
#define IDC_24BITS2                     1009
#define IDC_16BITS_DITHERED             1009
#define IDC_CONVERT1                    1009
#define IDC_USERDATA                    1010
#define IDC_USEFORAAC                   1011
#define IDC_OUTPUTFOLDER                1014
#define IDC_LOGO                        1019
#define IDC_PLUGINVER                   1050
#define IDC_FAADVER                     1051
#define IDC_MAIL1                       1052
#define IDC_MAIL2                       1053
#define IDC_MAIL3                       1054

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1020
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
