//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by aacdec.rc
//
#define IDS_ABOUT                       1
#define IDS_INFO                        2
#define IDD_ABOUT                       101
#define IDD_DIALOG_INFO                 102
#define IDB_BITMAP_AAC_LOGO             105
#define IDC_STATIC_VERSION              1000
#define IDC_LABEL_PROFILE               1001
#define IDC_LABEL_SAMPLERATE            1002
#define IDC_LABEL_CHANNELS              1003
#define IDC_LABEL_IBITRATE              1004
#define IDC_LABEL_BITRATE               1004
#define IDC_LABEL_BPS                   1005
#define IDC_STATIC_FAAD_VERSION         1006
#define IDC_LABEL_FRAMES_DECODED        1007
#define IDC_CHECK1                      1008
#define IDC_CHECK_DOWNMIX               1008
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
