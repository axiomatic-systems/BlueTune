#define PACKAGE "mpeg4ip"
#define VERSION "0.9.8.6"
