﻿+-----------------------------------------------------------------+
|                                                                 |
|                          cnv_FAAD Readme                        |
|                          ---------------                        |
|                                                                 |
+-----------------------------------------------------------------+

This code is given with FAAD package and does not contain executables.
This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License.
This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY.

----------------------------------------------------------------------------

cnv_FAAD is a decoder plugin for Winamp3;
it supports .aac/.mp4 files.

To use it:
----------
1) Copy "Wasabi SDK\Studio" folder into the folder where my sources are placed and rename it "SDK";

2) Build it;

3) Copy cnv_FAAD.wac into "Winamp3\Wacs" folder;

4) Copy FAAD_config.xml into "Winamp3\Wacs\xml\FAAD" folder.

----------------------------------------------------------------------------

For suggestions, bugs report, etc., you can contact me at
kreel@tiscali.it
