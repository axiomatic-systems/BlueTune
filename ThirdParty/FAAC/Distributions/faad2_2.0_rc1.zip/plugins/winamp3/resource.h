//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by FAAD.rc
//
#define IDD_ENCODER                     101
#define IDD_DECODER                     102
#define IDD_ABOUT                       103
#define IDB_AUDIOCODING                 104
#define IDB_EMAIL                       106
#define IDB_MPEG4IP                     107
#define IDC_RADIO_MPEG4                 1000
#define IDC_RADIO_MPEG2                 1001
#define IDC_RADIO_LOW                   1002
#define IDC_RADIO_MAIN                  1003
#define IDC_RADIO_SSR                   1004
#define IDC_RADIO_LTP                   1005
#define IDC_RADIO_RAW                   1006
#define IDC_RADIO_ADTS                  1007
#define IDC_CB_BANDWIDTH                1008
#define IDC_CB_SAMPLERATE               1008
#define IDC_CB_BITRATE                  1009
#define IDC_CHK_ALLOWMIDSIDE            1010
#define IDC_CHK_USETNS                  1011
#define IDC_CHK_USELFE                  1012
#define IDC_CHK_AUTOCFG                 1013
#define IDC_BTN_ABOUT                   1014
#define IDC_L_ABOUT                     1015
#define IDC_AUDIOCODING                 1016
#define IDC_EMAIL                       1017
#define IDC_MPEG4IP                     1018
#define IDC_RADIO_16                    1019
#define IDC_RADIO_24                    1020
#define IDC_RADIO_32                    1021
#define IDC_RADIO_FLOAT                 1022

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1023
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
