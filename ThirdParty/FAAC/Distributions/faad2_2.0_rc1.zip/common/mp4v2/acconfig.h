@BOTTOM@
#undef HAVE_IN_PORT_T

#undef HAVE_SOCKLEN_T

#undef HAVE_FPOS_T_POS

#undef ARCH_X86

#undef HAVE_IPv6

#undef HAVE_ST_ADDRINFO
